from app.modelos import create_tables

create_tables()
